self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3c7829495b5bbe30c52b53380f49bdf8",
    "url": "/index.html"
  },
  {
    "revision": "3ce9dbe2d2881d2d2dfd",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "f7a02aa37d900d29e0af",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "3ce9dbe2d2881d2d2dfd",
    "url": "/static/js/2.b34b798c.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.b34b798c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f7a02aa37d900d29e0af",
    "url": "/static/js/main.a32f4dd6.chunk.js"
  },
  {
    "revision": "71f4c0239130af0ab92e",
    "url": "/static/js/runtime-main.a0995136.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);