self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f8bd4d5648a73989a85763ba87fe818e",
    "url": "/hello-sosed/index.html"
  },
  {
    "revision": "75c18f9db4c1a9da7209",
    "url": "/hello-sosed/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "ae24a548e3f17a037878",
    "url": "/hello-sosed/static/css/main.ab6ba8d6.chunk.css"
  },
  {
    "revision": "75c18f9db4c1a9da7209",
    "url": "/hello-sosed/static/js/2.54b3ea32.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/hello-sosed/static/js/2.54b3ea32.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ae24a548e3f17a037878",
    "url": "/hello-sosed/static/js/main.af62f551.chunk.js"
  },
  {
    "revision": "12c2f693776fccc6c04b",
    "url": "/hello-sosed/static/js/runtime-main.afb583b7.js"
  }
]);